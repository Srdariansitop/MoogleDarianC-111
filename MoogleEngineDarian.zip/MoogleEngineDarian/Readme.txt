Pasos para inicializar el Moogle : 
El proyecto esta hecho en el Visual Studio (se puede abrir desde el code igual ) , Abres la carpeta Moogle dentro hay un ejecutable , abres el ejecutable , 
Entonces en la l�nea donde hay un comentario llamado ruta ahi debes poner la ubicacion de la carpeta de los archivos txt.
en la ultima l�nea puse unn Console.Readline q es recomandable poner en el visual studio(en el code me imagino q no tenga importancia) , 
Paso para iniciar el programa :
1- A la hora de realizar la busqueda le das a start ( en el visual studio ) , sigues las instrucciones en consola   
2- Entonces para realizar una busqueda diferente terminas de ejecutar el programa iniciado(enter en el visual studio )
3- Vuelves al paso 1 para buscar otra palabra 
Posdata
Si el programa da error con la ruta(no deberia) , debes crear un nuevo proyecto y copiar y pegar este. 
XD